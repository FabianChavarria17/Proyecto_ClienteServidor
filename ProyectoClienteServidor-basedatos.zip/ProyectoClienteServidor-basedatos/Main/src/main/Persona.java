package main;


public interface Persona
{
    String getUserID();
    void setUserID(String userID);

    String getDireccion();
    void setDireccion(String direccion);

    String getContrasena();
    void setContrasena(String contrasena);

    String getNombre();
    void setNombre(String nombre);

    String getCorreo();
    void setCorreo(String correo);
}
