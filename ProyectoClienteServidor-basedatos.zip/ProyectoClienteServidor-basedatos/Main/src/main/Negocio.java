package main;


public interface Negocio {
    String getNombre();
    String getDireccion();
    String getEmail();
    String getCategoria();
}
